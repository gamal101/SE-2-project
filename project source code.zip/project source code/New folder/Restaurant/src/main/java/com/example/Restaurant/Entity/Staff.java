package com.example.Restaurant.Entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "staff")
public class Staff extends Person
{

    @Column(name = "salary")
    private int salary;
    @Column(name = "manager_id")
    private int managerId;
    public int getManagerId() {
        return managerId;
    }

    public void setManagerId(int managerId) {
        this.managerId = managerId;
    }

    public Manager getManager() {
        return manager;
    }

    public void setManager(Manager manager) {
        this.manager = manager;
    }
    public int getSalary() {
        return salary;
    }

    public void setSalary(int salary) {
        this.salary = salary;
    }

    @JsonIgnore
    @ManyToOne()
    @JoinColumn(name = "manager_id",referencedColumnName = "id",insertable = false ,updatable = false)
    private Manager manager;

}

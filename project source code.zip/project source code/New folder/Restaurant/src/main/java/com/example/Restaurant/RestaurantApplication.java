package com.example.Restaurant;

import com.example.Restaurant.Entity.Person;
import com.example.Restaurant.Service.personService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.security.servlet.SecurityAutoConfiguration;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.context.annotation.Bean;

import java.util.ArrayList;


@EnableCaching
@SpringBootApplication( exclude = { SecurityAutoConfiguration.class } )
public class RestaurantApplication {

	public static void main(String[] args) {
		SpringApplication.run(RestaurantApplication.class, args);
	}
//	@Bean
//	@Autowired
//	public BCryptPasswordEncoder bCryptPasswordEncoder(){
//		return new BCryptPasswordEncoder();
//	}
//	@Bean
//	@Autowired
//	CommandLineRunner run(personService personService){
//		return args->{
////			personService.saveRole(new Role(1,"MANGER"));
////			personService.saveRole(new Role(2,"STAFF"));
////			personService.saveRole(new Role(3,"USER"));
//
//
//
//			personService.savePerson(new Person(1,"Mike","Mike@email.com",18,"Mike",new ArrayList<>()));
//
//			personService.addRoleToPerson("Mike","MANGER");
//
//		};
}





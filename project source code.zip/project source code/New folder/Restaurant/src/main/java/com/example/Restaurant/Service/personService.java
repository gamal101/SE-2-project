package com.example.Restaurant.Service;

import com.example.Restaurant.Entity.Person;
import com.example.Restaurant.Entity.Role;

import java.util.List;

public interface personService {
    Person savePerson(Person person);
    Role saveRole(Role role);
    void addRoleToPerson(String name, String roleName);
    Person getPerson(String name);
    List<Person> getPersons();
}

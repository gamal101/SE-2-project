package com.example.Restaurant.Entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;

import java.util.List;

@Entity
@Table(name = "manager")
public class Manager extends Person
{

    @Column(name = "salary")
    private int salary;
//    @JsonIgnore
//    @OneToMany(mappedBy = "manager",cascade = CascadeType.ALL)
//    private List<Product> products;

    public Manager() {
    }

    public Manager(int salary){//}, List<Product> products) {
        this.salary = salary;
        //this.products = products;
    }

    public int getSalary() {
        return salary;
    }

    public void setSalary(int salary) {
        this.salary = salary;
    }
}

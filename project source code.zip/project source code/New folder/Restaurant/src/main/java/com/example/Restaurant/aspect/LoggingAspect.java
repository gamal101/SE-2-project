package com.example.Restaurant.aspect;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;
import org.thymeleaf.util.StringUtils;


@Aspect
@Order(1)
@Component
public class LoggingAspect
{
    Logger log = LoggerFactory.getLogger(LoggingAspect.class);

    //User Logs
    @Before("execution(* com.example.Restaurant.Service.UserService.*(..))")
    public void logBeforeUser(JoinPoint joinPoint)
    {
        System.out.println("LoggingAspect: Method " + joinPoint.getSignature() + " is about to be executed.");
    }

    @After("execution(* com.example.Restaurant.Service.UserService.*(..))")
    public void logAfterUser(JoinPoint joinPoint)
    {
        System.out.println("LoggingAspect: Method " + joinPoint.getSignature() + " is executed.");
    }
    @Before("execution(* com.example.Restaurant.Service.UserService.savefeedback(..))")
    public void logBeforeAddFeedback(JoinPoint joinPoint)
    {
        System.out.println("LoggingAspect: Method " + joinPoint.getSignature() + "inserts the feedback comment and the UserId");
    }

    @After("execution(* com.example.Restaurant.Service.UserService.savefeedback(..))")
    public void logAfterAddFeedback(JoinPoint joinPoint)
    {
        System.out.println("LoggingAspect: Method " + joinPoint.getSignature() + "inserted the feedback comment and the UserId");
    }

    @Before("execution(* com.example.Restaurant.Service.UserService.savereservation(..))")
    public void logBeforeAddRes(JoinPoint joinPoint)
    {
        System.out.println("LoggingAspect: Method " + joinPoint.getSignature() + "inserts the reservation info");
    }

    @After("execution(* com.example.Restaurant.Service.UserService.savereservation(..))")
    public void logAfterAddRes(JoinPoint joinPoint)
    {
        System.out.println("LoggingAspect: Method " + joinPoint.getSignature() + "inserted the reservation info");
    }

    @Before("execution(* com.example.Restaurant.Service.UserService.saveOrder(..))")
    public void logBeforeAddorder(JoinPoint joinPoint)
    {
        System.out.println("LoggingAspect: Method " + joinPoint.getSignature() + "inserts the order info");
    }

    @After("execution(* com.example.Restaurant.Service.UserService.saveOrder(..))")
    public void logAfterAddorder(JoinPoint joinPoint)
    {
        System.out.println("LoggingAspect: Method " + joinPoint.getSignature() + "inserted the order info");
    }


    @Around(value = "execution(* com.example.Restaurant.Service.UserService.*(..))")
    public Object logTimeUser(ProceedingJoinPoint joinPoint) throws Throwable
    {
        long startTime = System.currentTimeMillis();
        StringBuilder sb = new StringBuilder("KPI:");
        sb.append("[").append(joinPoint.getKind()).append("]\tfor: ").append(joinPoint.getSignature())
                .append("\twithArgs: ").append("(").append(StringUtils.join(joinPoint.getArgs(), ",")).append(")");
        sb.append("\ttook: ");
        Object returnValue = joinPoint.proceed();
        log.info(sb.append(System.currentTimeMillis() - startTime).append(" ms.").toString());

        return returnValue;

    }
    //End user logs


    //Staff logs

    @Before("execution(* com.example.Restaurant.Service.StaffService.*(..))")
    public void logBeforeStaff(JoinPoint joinPoint)
    {
        System.out.println("LoggingAspect: Method " + joinPoint.getSignature() + " is about to be executed.");
    }

    @After("execution(* com.example.Restaurant.Service.StaffService.*(..))")
    public void logAfterStaff(JoinPoint joinPoint)
    {
        System.out.println("LoggingAspect: Method " + joinPoint.getSignature() + " is executed.");
    }


    @Before("execution(* com.example.Restaurant.Service.StaffService.findfeedback(..))")
    public void logBeforeFindFeedback(JoinPoint joinPoint)
    {
        System.out.println("LoggingAspect: Method " + joinPoint.getSignature() + "Finds the feedback comment and the UserId");
    }

    @After("execution(* com.example.Restaurant.Service.StaffService.findfeedback(..))")
    public void logAfterFindFeedback(JoinPoint joinPoint)
    {
        System.out.println("LoggingAspect: Method " + joinPoint.getSignature() + " Fetched the feedback comment and the UserId");
    }

    @Before("execution(* com.example.Restaurant.Service.StaffService.findreservation(..))")
    public void logBeforeFindRes(JoinPoint joinPoint)
    {
        System.out.println("LoggingAspect: Method " + joinPoint.getSignature() + "Finds the reservation info.");
    }

    @After("execution(* com.example.Restaurant.Service.StaffService.findreservation(..))")
    public void logAfterFindRes(JoinPoint joinPoint)
    {
        System.out.println("LoggingAspect: Method " + joinPoint.getSignature() + " Fetched the reservation info.");
    }

    @Before("execution(* com.example.Restaurant.Service.StaffService.findOrders(..))")
    public void logBeforeFindOrder(JoinPoint joinPoint)
    {
        System.out.println("LoggingAspect: Method " + joinPoint.getSignature() + "Finds the order info.");
    }

    @After("execution(* com.example.Restaurant.Service.StaffService.findOrders(..))")
    public void logAfterFindOrder(JoinPoint joinPoint)
    {
        System.out.println("LoggingAspect: Method " + joinPoint.getSignature() + " Fetched the order info.");
    }


    @Around(value = "execution(* com.example.Restaurant.Service.StaffService.*(..))")
    public Object logTimeStaff(ProceedingJoinPoint joinPoint) throws Throwable
    {
        long startTime = System.currentTimeMillis();
        StringBuilder sb = new StringBuilder("KPI:");
        sb.append("[").append(joinPoint.getKind()).append("]\tfor: ").append(joinPoint.getSignature())
                .append("\twithArgs: ").append("(").append(StringUtils.join(joinPoint.getArgs(), ",")).append(")");
        sb.append("\ttook: ");
        Object returnValue = joinPoint.proceed();
        log.info(sb.append(System.currentTimeMillis() - startTime).append(" ms.").toString());

        return returnValue;

    }
    //End staff logs



  //Manager Logs
  @Before("execution(* com.example.Restaurant.Service.ManagerServiseImpl.*(..))")
  public void logBeforeManager(JoinPoint joinPoint)
  {
      System.out.println("LoggingAspect: Method " + joinPoint.getSignature() + " is about to be executed.");
  }

  @After("execution(* com.example.Restaurant.Service.ManagerServiseImpl.*(..))")
  public void logAfterManager(JoinPoint joinPoint)
  {
        System.out.println("LoggingAspect: Method " + joinPoint.getSignature() + " is executed.");
  }

  @Around(value = "execution(* com.example.Restaurant.Service.ManagerServiseImpl.*(..))")
  public Object logTimeManager(ProceedingJoinPoint joinPoint) throws Throwable
  {
        long startTime = System.currentTimeMillis();
        StringBuilder sb = new StringBuilder("KPI:");
        sb.append("[").append(joinPoint.getKind()).append("]\tfor: ").append(joinPoint.getSignature())
                .append("\twithArgs: ").append("(").append(StringUtils.join(joinPoint.getArgs(), ",")).append(")");
        sb.append("\ttook: ");
        Object returnValue = joinPoint.proceed();
        log.info(sb.append(System.currentTimeMillis() - startTime).append(" ms.").toString());

        return returnValue;

  }


}

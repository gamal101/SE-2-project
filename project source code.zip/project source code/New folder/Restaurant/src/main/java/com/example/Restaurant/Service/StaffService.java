package com.example.Restaurant.Service;

import com.example.Restaurant.Entity.Feedback;
import com.example.Restaurant.Entity.Order;
import com.example.Restaurant.Entity.Reservation;
import com.example.Restaurant.Repository.FeedBackRepo;
import com.example.Restaurant.Repository.OrderRepo;
import com.example.Restaurant.Repository.ReservationRepo;
import com.example.Restaurant.Repository.StaffRepo;
import lombok.NoArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.CrossOrigin;

import java.util.List;

@Service
@CrossOrigin(origins = "*")
@NoArgsConstructor
public class StaffService {


    private FeedBackRepo feedBackRepo;
    private ReservationRepo reservationRepo;
    private OrderRepo orderRepo;

    @Autowired
    public StaffService(FeedBackRepo feedBackRepo, ReservationRepo reservationRepo, OrderRepo orderRepo) {
        this.feedBackRepo = feedBackRepo;
        this.reservationRepo = reservationRepo;
        this.orderRepo = orderRepo;

    }

    public List<Feedback> findfeedback() {
        return feedBackRepo.findAll();
    }

    public List<Reservation> findreservation() {
        return reservationRepo.findAll();
    }

    public List<Order> findOrders() {
        return orderRepo.findAll();
    }

    public void completeOrder(Long id) {
        Order order = orderRepo.findById(id).orElse(null);
        if (order != null) {
            order.setCompleted(true);
            orderRepo.save(order);
        }
    }
}

package com.example.Restaurant.Controller;


import com.example.Restaurant.Entity.Feedback;
import com.example.Restaurant.Service.FeedbackServices;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/task")
public class FeedbackController
{
   private final FeedbackServices feedbackServices;

   @Autowired
   public FeedbackController(FeedbackServices feedbackServices)
   {
       this.feedbackServices = feedbackServices;
   }

    @PostMapping
    public void addfeedback(@RequestBody Feedback feedback)
    {

        feedbackServices.savefeedback(feedback);
    }

    @GetMapping
    public List<Feedback> findfeedback()
    {
        return feedbackServices.getfeedback();
    }
}

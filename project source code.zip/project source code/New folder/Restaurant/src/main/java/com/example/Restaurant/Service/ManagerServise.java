package com.example.Restaurant.Service;
import com.example.Restaurant.Entity.Product;

import com.example.Restaurant.Entity.Staff;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public interface ManagerServise {
    String addProduct(Product product);
    String deleteProduct(int productId);
    List<Product> getAllProducts();
    String updateProduct(int productId, Product updatedProduct);
    String addStaff(Staff staff);
    List<Staff> getAllStaff();
    String deleteStaff(int staffId);
    String updateStaff(int staffId, Staff updatedStaff);
}

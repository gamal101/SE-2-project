package com.example.Restaurant.Service;

import com.example.Restaurant.Repository.PersonRepo;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

@Service
public class PesronDetailsImp implements UserDetailsService {
private final PersonRepo repo;

    public PesronDetailsImp(PersonRepo repo ) {
        this.repo = repo;
    }

    @Override
    public UserDetails loadUserByUsername(String name) throws UsernameNotFoundException {
        return repo.findByName(name) .orElseThrow(() -> new UsernameNotFoundException(name));
    }
}

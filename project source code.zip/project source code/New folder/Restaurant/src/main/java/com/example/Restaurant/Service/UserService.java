package com.example.Restaurant.Service;

import com.example.Restaurant.Entity.Feedback;
import com.example.Restaurant.Entity.Order;
import com.example.Restaurant.Entity.Reservation;
import com.example.Restaurant.Repository.FeedBackRepo;
import com.example.Restaurant.Repository.OrderRepo;
import com.example.Restaurant.Repository.ReservationRepo;
import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.CrossOrigin;

@Service
@CrossOrigin(origins = "*")
public class UserService
{
    private final FeedBackRepo feedBackRepo;
    private final ReservationRepo reservationRepo;
    private final OrderRepo orderRepo;
    @Autowired
    public UserService(FeedBackRepo feedBackRepo , ReservationRepo reservationRepo, OrderRepo orderRepo)
    {
        this.orderRepo=orderRepo;
        this.feedBackRepo = feedBackRepo;
        this.reservationRepo = reservationRepo;
    }


    public String savefeedback(Feedback feedback)
    {
        feedBackRepo.save(feedback);
        return "Feedback saved successfully";
    }

    //public String savereservation(Reservation reservation)
    //{
    //    reservationRepo.save(reservation);
    //    return "Reservation saved successfully";
    //}
    public String savereservation(Reservation reservation) {
        try {
            reservationRepo.save(reservation);
            return "Reservation saved successfully";
        } catch (Exception e) {
            e.printStackTrace(); // Print stack trace for debugging
            return "Failed to save reservation: " + e.getMessage(); // Return error message
        }
    }

    @Transactional
    public String saveOrder(Order order) {
        orderRepo.save(order);
        return "Order saved successfully";
    }
    public void addOrder(Order order) {
        orderRepo.save(order);
    }
}

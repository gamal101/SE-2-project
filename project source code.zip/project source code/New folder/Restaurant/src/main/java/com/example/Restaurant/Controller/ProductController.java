package com.example.Restaurant.Controller;

import com.example.Restaurant.Entity.Product;
import com.example.Restaurant.Service.ProductService;
import com.fasterxml.jackson.databind.deser.std.NumberDeserializers;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;
import java.util.Map;

    @RestController
    @RequestMapping("/products")
    public class ProductController {

        private final ProductService productService;

        @Autowired
        public ProductController(ProductService productService) {
            this.productService = productService;
        }

        @CrossOrigin(origins = "http://localhost:7070")
        @PostMapping("/get-product-price")
        public ResponseEntity<?> getProductPrice(@RequestBody Integer id) {
            try {
                if (id == null) {
                    return ResponseEntity.badRequest().body("Product ID is required");
                }

                // Fetch the product from the service
               Product product = productService.getProductById(id);

                if (product == null) {
                    return ResponseEntity.notFound().build();
                }

                // Get the product price
                int price = product.getPrice();

                // Return the product price
                return ResponseEntity.ok(price);
            } catch (Exception e) {
                e.printStackTrace();
                return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Internal server error");
            }
        }
    }


//public class ProductController {
//
//    private final ProductService productService;
//
//    @Autowired
//    public ProductController(ProductService productService) {
//        this.productService = productService;
//    }
//
//    @CrossOrigin(origins = "http://localhost:7070")
//    @PostMapping("/products/get-product")
//    public ResponseEntity<?> getProductById(@RequestBody Map<String, Integer> requestBody) {
//        try {
//            Integer id = requestBody.get("id");
//            if (id == null) {
//                return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Product ID is required");
//            }
//
//            Product product = productService.getProductById(id);
//
//            if (product == null) {
//                return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Product not found");
//            }
//
//            // Set manager to null to avoid serializing manager details
//            // product.setManager(null);
//
//            return ResponseEntity.ok(product);
//        } catch (Exception e) {
//            e.printStackTrace();
//            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Internal server error");
//        }
//    }




package com.example.Restaurant.Controller;

import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
@CrossOrigin(origins="*")

public class


AuthPageController {
    @GetMapping("/home")
    public String home() {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        String username = authentication.getName();
        System.out.println(username);
        return "home";
    }

    @GetMapping("/login")
    public String showLoginPage() {
        return "login"; // Make sure this returns "login"
    }

    @GetMapping("/register")
    public String showRegisterPage() {
        return "register"; // Make sure this returns "register"
    }
}

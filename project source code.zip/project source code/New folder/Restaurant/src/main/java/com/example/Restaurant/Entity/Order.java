package com.example.Restaurant.Entity;

import jakarta.persistence.*;
import jakarta.validation.constraints.Positive;
import org.springframework.data.annotation.Id;

import java.time.LocalDateTime;

import jakarta.persistence.*;
import org.springframework.data.annotation.Id;

@Entity
@Table(name = "orders")
public class Order {
    @jakarta.persistence.Id
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @Column(name = "product_id")
    private Integer productId; // Changed to Long to match the type of Product id

    @ManyToOne(fetch = FetchType.EAGER) // Assuming FetchType.LAZY for better performance
    @JoinColumn(name = "product_id", referencedColumnName = "id", insertable = false, updatable = false)
    private Product product;

    @Column(nullable = false)
    @Positive(message = "Quantity can't be less than 0 .")
    private int quantity;

    @Column(nullable = false)
    @Positive(message = "cost can't be less than 0 .")
    private double cost;

    @Column(nullable = false)
    private boolean completed;

    @Column(name = "user_id")
    private int userId;

    @ManyToOne(fetch = FetchType.EAGER) // Assuming FetchType.LAZY for better performance
    @JoinColumn(name = "user_id", referencedColumnName = "id", insertable = false, updatable = false)
    private User user;

    public Order() {

    }

    public void setCompleted(boolean b) {
        this.completed = true;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public int getUserId() {
        return userId;
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }

    public Product getProduct() {
        return product;
    }

    public void setProduct(Product product) {
        this.product = product;
    }

    public void setProductId(Integer productId) {
        this.productId = productId;
    }

    public Integer getProductId() {
        return productId;
    }
        public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public double getCost() {
        return cost;
    }

    public void setCost(double cost) {
        this.cost = cost;
    }

    public boolean isCompleted() {
        return completed;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Order(boolean completed, int quantity, double cost, int userId) {

        this.completed = completed;
        this.quantity = quantity;
        this.cost = cost;
        this.userId = userId;

    }

    // Constructors, getters, and setters
}



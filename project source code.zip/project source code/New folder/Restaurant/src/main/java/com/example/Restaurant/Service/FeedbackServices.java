package com.example.Restaurant.Service;


import com.example.Restaurant.Entity.Feedback;
import com.example.Restaurant.Repository.FeedBackRepo;
import lombok.NoArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@NoArgsConstructor
public class FeedbackServices
{
    private FeedBackRepo feedBackRepo;

    @Autowired
    public FeedbackServices(FeedBackRepo feedBackRepo)
    {
        this.feedBackRepo = feedBackRepo;
    }


    public String savefeedback(Feedback feedback)
    {
      feedBackRepo.save(feedback);
      return "Feedback saved successfully";
    }

    public List<Feedback> getfeedback()
    {
        return feedBackRepo.findAll();
    }
}

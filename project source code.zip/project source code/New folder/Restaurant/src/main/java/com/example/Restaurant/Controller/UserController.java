package com.example.Restaurant.Controller;

import com.example.Restaurant.Entity.Feedback;
import com.example.Restaurant.Entity.Order;
import com.example.Restaurant.Entity.Reservation;
import com.example.Restaurant.Service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@CrossOrigin(origins = "*")
@RequestMapping("/user")
public class UserController
{

    private UserService userService;

    @Autowired
    public UserController(UserService userService)
    {
        this.userService = userService;
    }

    @PostMapping("/add-feedback")
    public void addfeedback(@RequestBody Feedback feedback)
    {
        userService.savefeedback(feedback);
    }

    //@PostMapping("/add-reservation")
    //public void addreservation(@RequestBody Reservation reservation)
    //{
    //    userService.savereservation(reservation);
    //}

    @PostMapping("/add-reservation")
    public void addreservation(@RequestBody Reservation reservation) {
        System.out.println("Received reservation: " + reservation); // Print received reservation
        userService.savereservation(reservation);
    }
    @PostMapping("/add-order")
    public void addorder(@RequestBody Order order)
    {
        userService.addOrder(order);
        //return "add-order";
    }

}

package com.example.Restaurant.Entity;


import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
@Entity
@Table(name = "feedback")
public class Feedback
{
    @Id
    @SequenceGenerator(

            name = "feedback_sequence",
            sequenceName = "feedback_sequence",
            allocationSize = 1

    )
    @GeneratedValue(

            strategy =  GenerationType.SEQUENCE,
            generator = "feedback_sequence"

    )
    @Column(
            name = "id",
            updatable = false
    )
    private Long id;
    @Column(
            name = "comment",
            nullable = false,
            columnDefinition = "TEXT"
    )
    private String comment;
    @Column(
            name = "user_id"
    )
    private int user_id;

    @ManyToOne()
    @JoinColumn(name = "user_id",referencedColumnName = "id",insertable = false ,updatable = false)
    private User user;

     public Feedback(){}

    public Feedback(String comment, int user_id, User user)
    {
        this.comment = comment;
        this.user_id = user_id;
        this.user = user;
    }
}

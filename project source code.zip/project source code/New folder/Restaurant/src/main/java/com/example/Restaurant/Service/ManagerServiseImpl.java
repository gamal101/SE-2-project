package com.example.Restaurant.Service;

import com.example.Restaurant.Entity.Product;
import com.example.Restaurant.Entity.Staff;
import com.example.Restaurant.Repository.ProductRepo;
import com.example.Restaurant.Repository.StaffRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.security.crypto.password.PasswordEncoder;

import java.util.List;
import java.util.Optional;

@Service
public class ManagerServiseImpl implements ManagerServise{
    @Autowired
    private ProductRepo productRepo;
    @Autowired
    private StaffRepo staffRepo;
    @Autowired
    private  PasswordEncoder passwordEncoder;
    @Override
    public String addProduct(Product product) {
        Optional<Product> existingProduct = productRepo.findById(product.getId());
        if (existingProduct.isPresent()) {
            return "Product with ID " + product.getId() + " already exists";
        } else {
            productRepo.save(product);
            return "Product added successfully";
        }
    }
    public String deleteProduct(int productId){
        Optional<Product> existingProduct = productRepo.findById(productId);

        if (existingProduct.isPresent()) {
            productRepo.deleteById(productId);
            return "Product with ID " + productId + " deleted successfully";
        } else {
            return "Product with ID " + productId + " not found";
        }
    }
    public List<Product> getAllProducts() {
        return productRepo.findAll();
    }
    @Override
    public String updateProduct(int productId, Product updatedProduct) {
        // Retrieve the existing product from the database
        Optional<Product> existingProductOptional = productRepo.findById(productId);

        if (existingProductOptional.isPresent()) {
            // Update the existing product
            Product existingProduct = existingProductOptional.get();
            existingProduct.setName(updatedProduct.getName());
            existingProduct.setPrice(updatedProduct.getPrice());
            existingProduct.setManagerId(updatedProduct.getManagerId());

            // Save the updated product
            productRepo.save(existingProduct);

            return "Product with ID " + productId + " updated successfully";
        } else {
            return "Product with ID " + productId + " not found";
        }
    }
    @Override
    public String addStaff(Staff staff){
        Optional<Staff> existingStaff = staffRepo.findById(staff.getId());

        if (existingStaff.isPresent()) {
            return "Staff with ID " + staff.getId() + " already exists";
        } else {
            staff.setPassword(passwordEncoder.encode(staff.getPassword()));
            staffRepo.save(staff);
            return "Staff added successfully";
        }
    }


    public List<Staff> getAllStaff(){
        return staffRepo.findAll();
    }
    public String deleteStaff(int staffId){
        Optional<Staff> existingStaff = staffRepo.findById(staffId);

        if (existingStaff.isPresent()) {
            staffRepo.deleteById(staffId);
            return "Staff with ID " + staffId + " deleted successfully";
        } else {
            return "Staff with ID " + staffId + " not found";
        }
    }

    public StaffRepo getStaffRepo() {
        return staffRepo;
    }

    public void setStaffRepo(StaffRepo staffRepo) {
        this.staffRepo = staffRepo;
    }

    @Override
    public String updateStaff(int staffId, Staff updatedStaff) {
        Optional<Staff> existingStaffOptional = staffRepo.findById(staffId);

        if (existingStaffOptional.isPresent()) {
            Staff existingStaff = existingStaffOptional.get();
            existingStaff.setName(updatedStaff.getName());
            existingStaff.setEmail(updatedStaff.getEmail());
            existingStaff.setAge(updatedStaff.getAge());
            existingStaff.setPassword(passwordEncoder.encode(updatedStaff.getPassword()));
            existingStaff.setSalary(updatedStaff.getSalary());
            // Save the updated staff member
            staffRepo.save(existingStaff);

            return "Staff with ID " + staffId + " updated successfully";
        } else {
            return "Staff with ID " + staffId + " not found";
        }
    }
}

package com.example.Restaurant.Entity;

public enum Role {
    user,
    staff,
    manager
}

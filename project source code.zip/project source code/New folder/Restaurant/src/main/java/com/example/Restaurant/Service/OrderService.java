package com.example.Restaurant.Service;


import com.example.Restaurant.Repository.OrderRepo;

import com.example.Restaurant.Entity.Order;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class OrderService {

    @Autowired
    private OrderRepo orderRepository;

    public List<Order> getAllOrders() {
        return orderRepository.findAll();
    }

    public Order getOrderById(Long id) {
        return orderRepository.findById(id).orElse(null);
    }

    public void addOrder(Order order) {
        orderRepository.save(order);
    }

    public void deleteOrder(Long id) {
        orderRepository.deleteById(id);
    }

    public void processNextOrderInQueue() {
        List<Order> orders = getAllOrders();
        if (!orders.isEmpty()) {
            Order nextOrder = orders.get(0); // Assuming orders are processed in FIFO order
            // Process the order (e.g., mark it as completed, update inventory, etc.)
            nextOrder.setCompleted(true);
            orderRepository.save(nextOrder);
        }
    }

}


package com.example.Restaurant.Service;
import com.example.Restaurant.Entity.Product;
import com.example.Restaurant.Repository.ProductRepo;
import com.fasterxml.jackson.databind.deser.std.NumberDeserializers;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class ProductService {

    private final ProductRepo productRepository;

    @Autowired
    public ProductService(ProductRepo productRepository) {
        this.productRepository = productRepository;
    }

    public Product getProductById(Integer id) {
        return productRepository.findProductById(id);
    }

//    public Product getProductById(NumberDeserializers.IntegerDeserializer id) {
//    }
}



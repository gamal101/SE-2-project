package com.example.Restaurant.Controller;

import com.example.Restaurant.Entity.Feedback;
import com.example.Restaurant.Entity.Order;
import com.example.Restaurant.Entity.Reservation;
import com.example.Restaurant.Service.StaffService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@CrossOrigin(origins = "*")
@RequestMapping("/staff")
public class StaffController
{

  private final StaffService staffService;

  @Autowired
  public StaffController(StaffService staffService)
  {
    this.staffService = staffService;
  }

  @GetMapping("/get-feedback")
    public List<Feedback> ShowFeedback()
  {
      return  staffService.findfeedback();
  }

  @GetMapping("/get-reservations")
  public List<Reservation> ShowReservations(){return staffService.findreservation();}
  @CrossOrigin(origins = "http://localhost:7070")
  @GetMapping("/orders")
  public List<Order> showOrders() {
    return staffService.findOrders();
  }

  @GetMapping("/complete-order/{id}")
  public String completeOrder(@PathVariable Long id) {
    staffService.completeOrder(id);
    return "Order marked as completed";
  }

}

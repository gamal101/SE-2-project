package com.example.Restaurant.Entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Setter
@Getter
@Entity
@Table(name="product")
public class Product {
    @Id
    @SequenceGenerator(

            name = "product_sequence",
            sequenceName = "product_sequence",
            allocationSize = 1

    )
    @GeneratedValue(

            strategy =  GenerationType.SEQUENCE,
            generator = "product_sequence"

    )
    @Column(name="id")
    private int id;
    @Column(name="name")
    private String name;
    @Column(name = "manager_id")
    private int managerId;
    @Column(name="price")
    private int price;
//    @ManyToOne()
//    @JoinColumn(name = "manager_id",referencedColumnName = "id",insertable = false ,updatable = false)
//    private Manager manager;

    public Product() {
    }

    public Product(int id, String name, int managerId, int price, Manager manager) {
        this.id = id;
        this.name = name;
        this.managerId = managerId;
        this.price = price;
       // this.manager = manager;
    }

    public int getPrice() {
        return price;
    }

    public void setPrice(int price) {
        this.price = price;
    }
}

package com.example.Restaurant.Controller;

import com.example.Restaurant.Entity.Product;
import com.example.Restaurant.Entity.Staff;
import com.example.Restaurant.Repository.StaffRepo;
import com.example.Restaurant.Service.ManagerServise;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@CrossOrigin(origins = "*")
@RequestMapping("/manger")
public class ManagerController {
    @Autowired
    private ManagerServise managerServise;
    @Autowired
    private StaffRepo staffRepo;
    @PostMapping("/add-product")
    public String addProduct(@RequestBody Product product){
        return managerServise.addProduct(product);
    }
    @DeleteMapping("/delete-product/{productId}")
    public String deleteProduct(@PathVariable int productId) {
        return managerServise.deleteProduct(productId);
    }
    @GetMapping("/get-all-products")
    public List<Product> getAllProducts() {
        return managerServise.getAllProducts();
    }
    @PutMapping("/update-product/{productId}")
    public String updateProduct(@PathVariable int productId, @RequestBody Product updatedProduct) {
        return managerServise.updateProduct(productId, updatedProduct);
    }
    @PostMapping("/add-staff")
    public String addStaff(@RequestBody Staff staff){
        return managerServise.addStaff(staff);
    }

    @GetMapping("/get-all-staff")
    public List<Staff> getAllStaff() {
        return managerServise.getAllStaff();
    }
    @DeleteMapping("/delete-staff/{staffId}")
    public String deleteStaff(@PathVariable int staffId) {
        return managerServise.deleteStaff(staffId);
    }
    @PutMapping("/update-staff/{staffId}")
    public String updateStaff(@PathVariable int staffId, @RequestBody Staff updatedStaff) {
        return managerServise.updateStaff(staffId, updatedStaff);
    }

}

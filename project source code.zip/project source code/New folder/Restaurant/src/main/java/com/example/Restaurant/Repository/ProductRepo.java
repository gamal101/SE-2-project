package com.example.Restaurant.Repository;

import com.example.Restaurant.Entity.Product;
import com.fasterxml.jackson.databind.deser.std.NumberDeserializers;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.stereotype.Repository;

@Repository
@EnableJpaRepositories
public interface ProductRepo extends JpaRepository<Product,Integer> {
   // Product findProductById(Integer id);

    //Product findProductById(NumberDeserializers.IntegerDeserializer id);

    Product findProductById(Integer id);
}


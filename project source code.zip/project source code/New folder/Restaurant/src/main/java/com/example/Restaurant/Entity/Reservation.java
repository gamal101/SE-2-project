package com.example.Restaurant.Entity;

import jakarta.persistence.*;
import jakarta.validation.constraints.FutureOrPresent;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.Positive;
import lombok.Getter;
import lombok.Setter;

import java.time.LocalDate;
import java.time.LocalTime;

@Setter
@Getter
@Entity
@Table(name = "reservation")
public class Reservation
{
    @Id
    @SequenceGenerator(

            name = "reservation_sequence",
            sequenceName = "reservation_sequence",
            allocationSize = 1

    )
    @GeneratedValue(

            strategy =  GenerationType.SEQUENCE,
            generator = "reservation_sequence"

    )
    @Column(
            name = "id",
            updatable = false
    )
    private int id;
    @Column(name = "numoftable")
    @Positive(message = "Number of tables must be a positive number.")
    private int numoftable;
    @Column(name = "day")
    @FutureOrPresent(message = "Day must be in the present or future.")
    private LocalDate day;
    @Column(name = "hour")
    @Min(value = 8, message = "Hour must be at least 8.")
    @Max(value = 20, message = "Hour must be at most 20.")
    private LocalTime hour;

    @Column(
            name = "user_id"
    )
    private int user_id;

    @ManyToOne()
    @JoinColumn(name = "user_id",referencedColumnName = "id",insertable = false ,updatable = false)
    private User user;


    public Reservation(){}

    public Reservation(int id, int numoftable, LocalDate day, LocalTime hour, int user_id, User user) {
        this.id = id;
        this.numoftable = numoftable;
        this.day = day;
        this.hour = hour;
        this.user_id = user_id;
        this.user = user;
    }
}

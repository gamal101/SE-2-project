
//
// function registerUser(name, email, password) {
//     var url = "http://localhost:7070/register";
//     var person = {
//         name: name,
//         email: email,
//         password: password
//     };
//     console.log(person);
//     fetch(url,{
//         method:"POST",
//         headers:{
//             'Content-Type':'application/json'
//         },
//         body: JSON.stringify(person)
//     }).then(() => {
//         alert("Registration successful!");
//
//     }).catch(error => {
//         console.error('Error:', error);
//         alert("Registration failed. Please try again.");
//     });
// }
//
// document.getElementById("registrationForm").addEventListener("submit",(e)=>{
//     e.preventDefault();
//     console.log("done")
//     let userName = document.getElementById("userName").value;
//     let userEmail = document.getElementById("userEmail").value;
//     let userPassword = document.getElementById("userPassword").value;
//     console.log(userName, userEmail, userPassword);
//     registerUser(userName, userEmail, userPassword);
// });
//
// <form id="registrationForm" >
// <input type="text" id="userName" placeholder="Enter your username" required>
// <input type="text" id="userEmail" placeholder="Enter your email" required>
// <input type="text" id="userPassword" placeholder="Enter your password" required>
